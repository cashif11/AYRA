import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import '../models/conversation_model.dart';

class ConversationDatabase {
  static Database? _database;
  static const String dbName = 'ai_studio_pro.db';
  
  static const String tableMessages = 'messages';
  static const String tableSessions = 'sessions';
  static const String tableConfig = 'config';

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final directory = await getApplicationDocumentsDirectory();
    final path = join(directory.path, dbName);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createTables,
      onConfigure: (db) async {
        // Enable foreign keys
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _createTables(Database db, int version) async {
    // Messages table
    await db.execute('''
      CREATE TABLE $tableMessages (
        id TEXT PRIMARY KEY,
        sessionId TEXT NOT NULL,
        text TEXT NOT NULL,
        sender TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        type TEXT NOT NULL,
        audioPath TEXT,
        imagePath TEXT,
        metadata TEXT,
        FOREIGN KEY (sessionId) REFERENCES $tableSessions(id) ON DELETE CASCADE
      )
    ''');

    // Sessions table
    await db.execute('''
      CREATE TABLE $tableSessions (
        id TEXT PRIMARY KEY,
        createdAt TEXT NOT NULL,
        title TEXT NOT NULL,
        mode TEXT NOT NULL,
        messageCount INTEGER DEFAULT 0,
        lastUpdated TEXT
      )
    ''');

    // Create indexes for performance
    await db.execute(
      'CREATE INDEX idx_messages_sessionId ON $tableMessages(sessionId)'
    );
    await db.execute(
      'CREATE INDEX idx_messages_timestamp ON $tableMessages(timestamp)'
    );
    await db.execute(
      'CREATE INDEX idx_sessions_createdAt ON $tableSessions(createdAt)'
    );
  }

  // Initialize database
  Future<void> init() async {
    await database;
  }

  // MESSAGES OPERATIONS
  Future<void> saveMessage(ConversationMessage message) async {
    final db = await database;
    
    await db.insert(
      tableMessages,
      {
        'id': message.id,
        'sessionId': message.sessionId,
        'text': message.text,
        'sender': message.sender,
        'timestamp': message.timestamp.toIso8601String(),
        'type': message.type,
        'audioPath': message.audioPath,
        'imagePath': message.imagePath,
        'metadata': message.metadata != null 
            ? _serializeMap(message.metadata!)
            : null,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );

    // Update session message count
    await db.rawUpdate(
      'UPDATE $tableSessions SET messageCount = messageCount + 1, '
      'lastUpdated = ? WHERE id = ?',
      [DateTime.now().toIso8601String(), message.sessionId],
    );
  }

  Future<List<ConversationMessage>> getMessages(String sessionId) async {
    final db = await database;
    
    final maps = await db.query(
      tableMessages,
      where: 'sessionId = ?',
      whereArgs: [sessionId],
      orderBy: 'timestamp ASC',
    );

    return List.generate(maps.length, (i) {
      return ConversationMessage(
        id: maps[i]['id'] as String,
        sessionId: maps[i]['sessionId'] as String,
        text: maps[i]['text'] as String,
        sender: maps[i]['sender'] as String,
        timestamp: DateTime.parse(maps[i]['timestamp'] as String),
        type: maps[i]['type'] as String,
        audioPath: maps[i]['audioPath'] as String?,
        imagePath: maps[i]['imagePath'] as String?,
        metadata: maps[i]['metadata'] != null
            ? _deserializeMap(maps[i]['metadata'] as String)
            : null,
      );
    });
  }

  Future<void> deleteMessages(String sessionId) async {
    final db = await database;
    await db.delete(
      tableMessages,
      where: 'sessionId = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> deleteMessage(String messageId) async {
    final db = await database;
    await db.delete(
      tableMessages,
      where: 'id = ?',
      whereArgs: [messageId],
    );
  }

  // SESSIONS OPERATIONS
  Future<void> saveSession(ConversationSession session) async {
    final db = await database;
    
    await db.insert(
      tableSessions,
      {
        'id': session.id,
        'createdAt': session.createdAt.toIso8601String(),
        'title': session.title,
        'mode': session.mode,
        'messageCount': session.messageCount,
        'lastUpdated': session.lastUpdated?.toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<ConversationSession>> getSessions() async {
    final db = await database;
    
    final maps = await db.query(
      tableSessions,
      orderBy: 'createdAt DESC',
    );

    return List.generate(maps.length, (i) {
      return ConversationSession(
        id: maps[i]['id'] as String,
        createdAt: DateTime.parse(maps[i]['createdAt'] as String),
        title: maps[i]['title'] as String,
        mode: maps[i]['mode'] as String,
        messageCount: maps[i]['messageCount'] as int? ?? 0,
        lastUpdated: maps[i]['lastUpdated'] != null
            ? DateTime.parse(maps[i]['lastUpdated'] as String)
            : null,
      );
    });
  }

  Future<ConversationSession?> getSession(String sessionId) async {
    final db = await database;
    
    final maps = await db.query(
      tableSessions,
      where: 'id = ?',
      whereArgs: [sessionId],
    );

    if (maps.isEmpty) return null;

    final map = maps.first;
    return ConversationSession(
      id: map['id'] as String,
      createdAt: DateTime.parse(map['createdAt'] as String),
      title: map['title'] as String,
      mode: map['mode'] as String,
      messageCount: map['messageCount'] as int? ?? 0,
      lastUpdated: map['lastUpdated'] != null
          ? DateTime.parse(map['lastUpdated'] as String)
          : null,
    );
  }

  Future<void> deleteSession(String sessionId) async {
    final db = await database;
    // Messages will cascade delete due to foreign key
    await db.delete(
      tableSessions,
      where: 'id = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> updateSessionTitle(String sessionId, String newTitle) async {
    final db = await database;
    await db.update(
      tableSessions,
      {'title': newTitle},
      where: 'id = ?',
      whereArgs: [sessionId],
    );
  }

  // SEARCH & ANALYTICS
  Future<int> getTotalMessageCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM $tableMessages');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<int> getSessionCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM $tableSessions');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<List<ConversationMessage>> searchMessages(String query) async {
    final db = await database;
    
    final maps = await db.query(
      tableMessages,
      where: 'text LIKE ?',
      whereArgs: ['%$query%'],
      orderBy: 'timestamp DESC',
    );

    return List.generate(maps.length, (i) {
      return ConversationMessage(
        id: maps[i]['id'] as String,
        sessionId: maps[i]['sessionId'] as String,
        text: maps[i]['text'] as String,
        sender: maps[i]['sender'] as String,
        timestamp: DateTime.parse(maps[i]['timestamp'] as String),
        type: maps[i]['type'] as String,
      );
    });
  }

  // UTILITIES
  String _serializeMap(Map<String, dynamic> map) {
    // Simple JSON serialization
    return map.toString();
  }

  Map<String, dynamic> _deserializeMap(String mapString) {
    // Would need proper JSON parsing in production
    return {};
  }

  Future<void> close() async {
    final db = await database;
    await db.close();
  }

  Future<void> clear() async {
    final db = await database;
    await db.delete(tableMessages);
    await db.delete(tableSessions);
  }

  Future<void> deleteDatabase() async {
    final directory = await getApplicationDocumentsDirectory();
    final path = join(directory.path, dbName);
    await databaseFactory.deleteDatabase(path);
    _database = null;
  }
}
