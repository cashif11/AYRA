import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/ai_provider_pro.dart';

class HomeScreenPro extends StatefulWidget {
  const HomeScreenPro({Key? key}) : super(key: key);

  @override
  State<HomeScreenPro> createState() => _HomeScreenProState();
}

class _HomeScreenProState extends State<HomeScreenPro> {
  late TextEditingController _messageController;
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _messageController = TextEditingController();
    _scrollController = ScrollController();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final aiProvider = context.read<AIProviderPro>();
        if (aiProvider.isConnected) {
          await aiProvider.disconnect();
        }
        return true;
      },
      child: Scaffold(
        appBar: _buildAppBar(),
        body: Consumer<AIProviderPro>(
          builder: (context, aiProvider, _) {
            return Column(
              children: [
                // Status indicator and mode selector
                _buildControlPanel(context, aiProvider),
                
                // Conversation display
                Expanded(
                  child: aiProvider.currentSession != null
                      ? _buildConversation(aiProvider)
                      : _buildEmptyState(context, aiProvider),
                ),
                
                // Input area
                if (aiProvider.isConnected)
                  _buildInputArea(context, aiProvider),
              ],
            );
          },
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: const Text('AI Studio Pro'),
      actions: [
        Consumer<AIProviderPro>(
          builder: (context, aiProvider, _) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Center(
                child: Text(
                  aiProvider.connectionStatus,
                  style: TextStyle(
                    fontSize: 12,
                    color: aiProvider.isConnected ? Colors.green : Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildControlPanel(BuildContext context, AIProviderPro aiProvider) {
    return Container(
      color: const Color(0xFF1E293B),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Connection Status
          Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: aiProvider.isConnected ? Colors.green : Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                aiProvider.isConnected ? 'Connected' : 'Disconnected',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: aiProvider.isConnected ? Colors.green : Colors.red,
                ),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: aiProvider.isConnected
                    ? () => aiProvider.disconnect()
                    : () => aiProvider.connect(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: aiProvider.isConnected
                      ? Colors.red.withOpacity(0.8)
                      : Colors.green.withOpacity(0.8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                ),
                child: Text(
                  aiProvider.isConnected ? 'Disconnect' : 'Connect',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          
          if (aiProvider.isConnected) ...[
            const SizedBox(height: 16),
            
            // Mode Selector
            const Text(
              'Mode',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 8),
            
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildModeButton('Audio', 'audio', aiProvider),
                  const SizedBox(width: 8),
                  _buildModeButton('Camera', 'camera', aiProvider),
                  const SizedBox(width: 8),
                  _buildModeButton('Combined', 'combined', aiProvider),
                  const SizedBox(width: 8),
                  _buildModeButton('Text', 'text', aiProvider),
                ],
              ),
            ),
            
            const SizedBox(height: 12),
            
            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: aiProvider.isListening
                        ? () => aiProvider.stopListening()
                        : () => aiProvider.startListening(),
                    icon: Icon(
                      aiProvider.isListening ? Icons.mic_off : Icons.mic,
                    ),
                    label: Text(
                      aiProvider.isListening ? 'Stop' : 'Microphone',
                      style: const TextStyle(fontSize: 12),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: aiProvider.isListening
                          ? Colors.orange
                          : Colors.indigo,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: aiProvider.isCameraStreaming
                        ? () => aiProvider.stopCameraStream()
                        : () => aiProvider.startCameraStream(),
                    icon: Icon(
                      aiProvider.isCameraStreaming
                          ? Icons.camera_off
                          : Icons.camera,
                    ),
                    label: Text(
                      aiProvider.isCameraStreaming ? 'Stop' : 'Camera',
                      style: const TextStyle(fontSize: 12),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: aiProvider.isCameraStreaming
                          ? Colors.orange
                          : Colors.indigo,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildModeButton(
    String label,
    String mode,
    AIProviderPro aiProvider,
  ) {
    final isSelected = aiProvider.selectedMode == mode;
    
    return ElevatedButton(
      onPressed: () => aiProvider.setMode(mode),
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected
            ? const Color(0xFF6366F1)
            : Colors.grey[700],
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 12,
          color: Colors.white,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildConversation(AIProviderPro aiProvider) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
    
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(16),
      itemCount: aiProvider.messages.length,
      itemBuilder: (context, index) {
        final message = aiProvider.messages[index];
        final isUser = message.sender == 'user';
        
        return Align(
          alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: isUser ? const Color(0xFF6366F1) : const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(12),
              border: isUser
                  ? null
                  : Border.all(color: Colors.grey.withOpacity(0.2)),
            ),
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.75,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  message.text,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formatTime(message.timestamp),
                  style: TextStyle(
                    color: Colors.grey.withOpacity(0.6),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState(BuildContext context, AIProviderPro aiProvider) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            '👋',
            style: TextStyle(fontSize: 64),
          ),
          const SizedBox(height: 16),
          const Text(
            'Ready to Chat',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Connect and start conversing with AI',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[400],
            ),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: () => aiProvider.connect(),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6366F1),
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 12,
              ),
            ),
            child: const Text(
              'Connect Now',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputArea(BuildContext context, AIProviderPro aiProvider) {
    return Container(
      color: const Color(0xFF1E293B),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              decoration: InputDecoration(
                hintText: 'Type a message...',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF0F172A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Colors.grey,
                    width: 0.5,
                  ),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
              ),
              style: const TextStyle(color: Colors.white),
              maxLines: null,
              textInputAction: TextInputAction.send,
              onSubmitted: (text) {
                if (text.isNotEmpty) {
                  aiProvider.sendMessage(text);
                  _messageController.clear();
                  _scrollToBottom();
                }
              },
            ),
          ),
          const SizedBox(width: 8),
          FloatingActionButton(
            mini: true,
            onPressed: aiProvider.isProcessing
                ? null
                : () {
                    if (_messageController.text.isNotEmpty) {
                      aiProvider.sendMessage(_messageController.text);
                      _messageController.clear();
                      _scrollToBottom();
                    }
                  },
            backgroundColor: const Color(0xFF6366F1),
            child: aiProvider.isProcessing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation(Colors.white),
                    ),
                  )
                : const Icon(Icons.send),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final msgDate = DateTime(dateTime.year, dateTime.month, dateTime.day);
    
    if (msgDate == today) {
      return '${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else {
      return '${dateTime.month}/${dateTime.day}';
    }
  }
}
