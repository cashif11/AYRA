import 'package:flutter/foundation.dart';
import 'dart:async';
import 'dart:typed_data';
import 'package:uuid/uuid.dart';
import '../services/gemini_live_service.dart';
import '../models/conversation_model.dart';
import '../database/conversation_database.dart';

class AIProviderPro extends ChangeNotifier {
  // Services
  late GeminiLiveService _geminiService;
  late ConversationDatabase _database;
  
  // State
  bool _isConnected = false;
  bool _isListening = false;
  bool _isCameraStreaming = false;
  bool _isProcessing = false;
  String _selectedMode = 'audio'; // 'audio', 'camera', 'combined', 'text'
  String _connectionStatus = 'Disconnected';
  
  // Data
  List<ConversationMessage> _messages = [];
  List<ConversationSession> _sessions = [];
  ConversationSession? _currentSession;
  
  // API Key (encrypted)
  String? _apiKey;
  
  // Subscriptions
  StreamSubscription? _responseSubscription;
  StreamSubscription? _audioSubscription;
  StreamSubscription? _statusSubscription;
  
  // Getters
  bool get isConnected => _isConnected;
  bool get isListening => _isListening;
  bool get isCameraStreaming => _isCameraStreaming;
  bool get isProcessing => _isProcessing;
  String get selectedMode => _selectedMode;
  String get connectionStatus => _connectionStatus;
  List<ConversationMessage> get messages => _messages;
  List<ConversationSession> get sessions => _sessions;
  ConversationSession? get currentSession => _currentSession;
  bool get hasValidApiKey => _apiKey != null && _apiKey!.isNotEmpty;

  /// Initialize provider
  Future<void> initialize({required String? apiKey}) async {
    try {
      _apiKey = apiKey;
      _database = ConversationDatabase();
      await _database.init();
      
      _geminiService = GeminiLiveService();
      
      // Load saved sessions
      _sessions = await _database.getSessions();
      
      debugPrint('✅ AI Provider initialized');
    } catch (e) {
      debugPrint('❌ Initialization error: $e');
    }
  }

  /// Set API key
  Future<void> setApiKey(String key) async {
    try {
      _apiKey = key;
      notifyListeners();
      debugPrint('🔑 API key set');
    } catch (e) {
      debugPrint('❌ Error setting API key: $e');
    }
  }

  /// Connect to Gemini Live API
  Future<void> connect() async {
    if (_isConnected || _apiKey == null) return;
    
    try {
      _updateStatus('Connecting...');
      
      // Generate session ID
      const uuid = Uuid();
      final sessionId = uuid.v4();
      
      // Create new session
      _currentSession = ConversationSession(
        id: sessionId,
        createdAt: DateTime.now(),
        title: 'Session ${_sessions.length + 1}',
        mode: _selectedMode,
      );
      
      // Save session
      await _database.saveSession(_currentSession!);
      _sessions.add(_currentSession!);
      
      // Initialize and connect Gemini service
      await _geminiService.initialize(
        apiKey: _apiKey!,
        sessionId: sessionId,
      );
      await _geminiService.connect();
      
      // Setup listeners
      _setupStreamListeners();
      
      _isConnected = true;
      _updateStatus('Connected');
      notifyListeners();
      
      debugPrint('✅ Connected to Gemini Live');
    } catch (e) {
      _updateStatus('Connection failed: $e');
      debugPrint('❌ Connection error: $e');
    }
  }

  /// Setup stream listeners
  void _setupStreamListeners() {
    // Text responses
    _responseSubscription?.cancel();
    _responseSubscription = _geminiService.responses.listen((text) {
      _addMessage(
        ConversationMessage(
          id: const Uuid().v4(),
          sessionId: _currentSession!.id,
          text: text,
          sender: 'ai',
          timestamp: DateTime.now(),
          type: 'text',
        ),
      );
    });
    
    // Audio responses
    _audioSubscription?.cancel();
    _audioSubscription = _geminiService.audioResponses.listen((audio) {
      debugPrint('🔊 Received audio: ${audio.length} bytes');
    });
    
    // Status updates
    _statusSubscription?.cancel();
    _statusSubscription = _geminiService.statusUpdates.listen((status) {
      _updateStatus(status);
    });
  }

  /// Disconnect from Gemini
  Future<void> disconnect() async {
    try {
      await _geminiService.disconnect();
      
      _responseSubscription?.cancel();
      _audioSubscription?.cancel();
      _statusSubscription?.cancel();
      
      _isConnected = false;
      _isListening = false;
      _isCameraStreaming = false;
      
      _updateStatus('Disconnected');
      notifyListeners();
      
      debugPrint('✅ Disconnected');
    } catch (e) {
      debugPrint('❌ Disconnect error: $e');
    }
  }

  /// Start audio listening
  Future<void> startListening() async {
    if (!_isConnected) return;
    
    try {
      await _geminiService.startAudioStream();
      _isListening = true;
      _updateStatus('Listening...');
      notifyListeners();
      debugPrint('🎤 Listening started');
    } catch (e) {
      debugPrint('❌ Error starting audio: $e');
    }
  }

  /// Stop audio listening
  Future<void> stopListening() async {
    try {
      await _geminiService.stopAudioStream();
      _isListening = false;
      _updateStatus('Ready');
      notifyListeners();
      debugPrint('🛑 Listening stopped');
    } catch (e) {
      debugPrint('❌ Error stopping audio: $e');
    }
  }

  /// Start camera streaming
  Future<void> startCameraStream() async {
    if (!_isConnected) return;
    
    try {
      await _geminiService.startCameraStream(frameIntervalMs: 500);
      _isCameraStreaming = true;
      _updateStatus('Camera streaming...');
      notifyListeners();
      debugPrint('📷 Camera stream started');
    } catch (e) {
      debugPrint('❌ Error starting camera: $e');
    }
  }

  /// Stop camera streaming
  Future<void> stopCameraStream() async {
    try {
      await _geminiService.stopCameraStream();
      _isCameraStreaming = false;
      _updateStatus('Ready');
      notifyListeners();
      debugPrint('🛑 Camera stream stopped');
    } catch (e) {
      debugPrint('❌ Error stopping camera: $e');
    }
  }

  /// Send text message
  Future<void> sendMessage(String text) async {
    if (!_isConnected || text.isEmpty) return;
    
    try {
      _isProcessing = true;
      notifyListeners();
      
      // Add user message
      final userMessage = ConversationMessage(
        id: const Uuid().v4(),
        sessionId: _currentSession!.id,
        text: text,
        sender: 'user',
        timestamp: DateTime.now(),
        type: 'text',
      );
      _addMessage(userMessage);
      
      // Send to Gemini
      await _geminiService.sendText(text);
      
      _isProcessing = false;
      notifyListeners();
      
      debugPrint('📤 Message sent: $text');
    } catch (e) {
      _isProcessing = false;
      debugPrint('❌ Error sending message: $e');
      notifyListeners();
    }
  }

  /// Set input mode
  void setMode(String mode) {
    _selectedMode = mode;
    notifyListeners();
    debugPrint('🔧 Mode changed to: $mode');
  }

  /// Add message to conversation
  void _addMessage(ConversationMessage message) {
    _messages.add(message);
    // Save to database
    _database.saveMessage(message).then((_) {
      notifyListeners();
    });
  }

  /// Load conversation session
  Future<void> loadSession(String sessionId) async {
    try {
      _currentSession = _sessions.firstWhere((s) => s.id == sessionId);
      _messages = await _database.getMessages(sessionId);
      notifyListeners();
      debugPrint('✅ Session loaded: $sessionId');
    } catch (e) {
      debugPrint('❌ Error loading session: $e');
    }
  }

  /// Create new session
  Future<void> newSession() async {
    try {
      await disconnect();
      _messages.clear();
      _currentSession = null;
      notifyListeners();
      debugPrint('✅ New session started');
    } catch (e) {
      debugPrint('❌ Error creating session: $e');
    }
  }

  /// Clear conversation
  Future<void> clearConversation() async {
    if (_currentSession != null) {
      try {
        await _database.deleteMessages(_currentSession!.id);
        _messages.clear();
        notifyListeners();
        debugPrint('🗑️ Conversation cleared');
      } catch (e) {
        debugPrint('❌ Error clearing conversation: $e');
      }
    }
  }

  /// Delete session
  Future<void> deleteSession(String sessionId) async {
    try {
      await _database.deleteSession(sessionId);
      _sessions.removeWhere((s) => s.id == sessionId);
      
      if (_currentSession?.id == sessionId) {
        await disconnect();
        _currentSession = null;
        _messages.clear();
      }
      
      notifyListeners();
      debugPrint('🗑️ Session deleted: $sessionId');
    } catch (e) {
      debugPrint('❌ Error deleting session: $e');
    }
  }

  /// Update connection status
  void _updateStatus(String status) {
    _connectionStatus = status;
    notifyListeners();
  }

  /// Export conversation
  Future<String> exportConversation() async {
    if (_currentSession == null) return '';
    
    try {
      final buffer = StringBuffer();
      buffer.writeln('=== Conversation: ${_currentSession!.title} ===');
      buffer.writeln('Date: ${_currentSession!.createdAt}');
      buffer.writeln('Mode: ${_currentSession!.mode}');
      buffer.writeln('');
      
      for (final message in _messages) {
        buffer.writeln('${message.sender.toUpperCase()}: ${message.text}');
        buffer.writeln('');
      }
      
      return buffer.toString();
    } catch (e) {
      debugPrint('❌ Error exporting: $e');
      return '';
    }
  }

  @override
  void dispose() {
    _responseSubscription?.cancel();
    _audioSubscription?.cancel();
    _statusSubscription?.cancel();
    _geminiService.dispose();
    _database.close();
    super.dispose();
  }
}
