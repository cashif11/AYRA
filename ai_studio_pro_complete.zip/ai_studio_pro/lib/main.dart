import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen_pro.dart';
import 'screens/setup_screen.dart';
import 'providers/ai_provider_pro.dart';

void main() {
  runApp(const AIStudioPro());
}

class AIStudioPro extends StatelessWidget {
  const AIStudioPro({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AIProviderPro(),
        ),
      ],
      child: MaterialApp(
        title: 'AI Studio Pro',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF6366F1),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF0F172A),
          appBarTheme: AppBarTheme(
            backgroundColor: const Color(0xFF1E293B),
            elevation: 0,
            centerTitle: true,
            titleTextStyle: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          cardTheme: CardTheme(
            color: const Color(0xFF1E293B),
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        home: const AppWrapper(),
      ),
    );
  }
}

class AppWrapper extends StatefulWidget {
  const AppWrapper({Key? key}) : super(key: key);

  @override
  State<AppWrapper> createState() => _AppWrapperState();
}

class _AppWrapperState extends State<AppWrapper> {
  late AIProviderPro _aiProvider;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    _aiProvider = context.read<AIProviderPro>();
    
    // Load API key from storage or use empty (will prompt user)
    String? apiKey = ''; // In production, retrieve from secure storage
    
    await _aiProvider.initialize(apiKey: apiKey);
    
    setState(() {
      _initialized = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Consumer<AIProviderPro>(
      builder: (context, aiProvider, _) {
        // Show setup if no API key
        if (!aiProvider.hasValidApiKey) {
          return const SetupScreen();
        }

        // Show main app
        return const HomeScreenPro();
      },
    );
  }
}
