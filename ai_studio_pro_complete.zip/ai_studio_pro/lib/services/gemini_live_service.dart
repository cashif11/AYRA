import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:camera/camera.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:image/image.dart' as img;
import 'package:logger/logger.dart';

class GeminiLiveService {
  static const String _apiVersion = 'v1beta';
  static const String _model = 'models/gemini-2.5-flash-native-audio-preview-12-2025';
  
  late String _apiKey;
  late String _sessionId;
  
  WebSocketChannel? _wsChannel;
  bool _isConnected = false;
  bool _isInitialized = false;
  
  // Audio
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  StreamSubscription<Uint8List>? _audioSubscription;
  
  // Camera
  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  Timer? _frameTimer;
  
  // Streaming
  final StreamController<String> _responseController = StreamController<String>.broadcast();
  final StreamController<Uint8List> _audioResponseController = StreamController<Uint8List>.broadcast();
  final StreamController<String> _statusController = StreamController<String>.broadcast();
  
  // Logging
  final Logger _logger = Logger(
    printer: PrettyPrinter(
      methodCount: 2,
      errorMethodCount: 8,
      lineLength: 120,
      colors: true,
      printEmojis: true,
    ),
  );
  
  // Config
  late Map<String, dynamic> _liveConfig;
  
  // Stream getters
  Stream<String> get responses => _responseController.stream;
  Stream<Uint8List> get audioResponses => _audioResponseController.stream;
  Stream<String> get statusUpdates => _statusController.stream;
  bool get isConnected => _isConnected;

  /// Initialize the Gemini Live Service
  Future<void> initialize({
    required String apiKey,
    required String sessionId,
  }) async {
    try {
      _apiKey = apiKey;
      _sessionId = sessionId;
      
      _logger.i('🚀 Initializing Gemini Live Service');
      
      // Initialize camera
      _cameras = await availableCameras();
      if (_cameras!.isNotEmpty) {
        _cameraController = CameraController(
          _cameras![0],
          ResolutionPreset.high,
          enableAudio: false,
        );
        await _cameraController!.initialize();
        _logger.i('📷 Camera initialized');
      }
      
      // Configure Gemini Live API
      _liveConfig = {
        'response_modalities': ['AUDIO'],
        'media_resolution': 'MEDIA_RESOLUTION_HIGH',
        'speech_config': {
          'voice_config': {
            'prebuilt_voice_config': {
              'voice_name': 'Zephyr',
            },
          },
        },
        'context_window_compression': {
          'trigger_tokens': 25600,
          'sliding_window': {
            'target_tokens': 12800,
          },
        },
        'system_instruction': {
          'parts': [
            {
              'text': 'You are a professional AI assistant. Respond naturally and helpfully to all queries. '
                      'You have access to the user\'s camera feed and microphone. '
                      'Analyze visual information when provided. Be concise but thorough.',
            },
          ],
        },
      };
      
      _isInitialized = true;
      _statusController.add('Initialized');
      _logger.i('✅ Initialization complete');
      
    } catch (e) {
      _logger.e('❌ Initialization error: $e');
      rethrow;
    }
  }

  /// Connect to Gemini Live API
  Future<void> connect() async {
    if (_isConnected) return;
    
    try {
      _statusController.add('Connecting...');
      _logger.w('🔌 Connecting to Gemini Live API');
      
      // Build WebSocket URL with authentication
      final wsUrl = Uri.parse(
        'wss://generativelanguage.googleapis.com/google.ai.generativelanguage.${_apiVersion}/'
        'GenerativeService.BidiGenerateContent'
        '?key=$_apiKey'
      );
      
      // Connect with headers
      _wsChannel = WebSocketChannel.connect(
        wsUrl,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'AI-Studio-Pro/1.0',
        },
      );
      
      // Wait for connection
      await _wsChannel!.ready;
      _isConnected = true;
      _logger.i('✅ Connected to Gemini Live API');
      _statusController.add('Connected');
      
      // Send initial configuration
      await _sendConfig();
      
      // Start listening to responses
      _listenToResponses();
      
    } catch (e) {
      _isConnected = false;
      _logger.e('❌ Connection failed: $e');
      _statusController.add('Connection failed: $e');
      rethrow;
    }
  }

  /// Send configuration to Gemini
  Future<void> _sendConfig() async {
    try {
      final configMessage = {
        'setup': {
          'model': _model,
          'config': _liveConfig,
        },
      };
      
      _wsChannel!.sink.add(jsonEncode(configMessage));
      _logger.d('📤 Config sent');
    } catch (e) {
      _logger.e('Error sending config: $e');
    }
  }

  /// Listen to incoming responses from Gemini
  void _listenToResponses() {
    _wsChannel!.stream.listen(
      (data) {
        try {
          final response = jsonDecode(data);
          _processResponse(response);
        } catch (e) {
          _logger.e('Error processing response: $e');
        }
      },
      onError: (error) {
        _logger.e('WebSocket error: $error');
        _statusController.add('Connection error: $error');
        _isConnected = false;
      },
      onDone: () {
        _logger.w('WebSocket closed');
        _isConnected = false;
        _statusController.add('Disconnected');
      },
    );
  }

  /// Process incoming response from Gemini
  void _processResponse(Map<String, dynamic> response) {
    try {
      // Handle text responses
      if (response['serverContent'] != null) {
        final serverContent = response['serverContent'];
        
        if (serverContent['modelTurn'] != null) {
          final parts = serverContent['modelTurn']['parts'] as List?;
          
          if (parts != null) {
            for (var part in parts) {
              // Text response
              if (part['text'] != null) {
                final text = part['text'] as String;
                _logger.i('📝 Text: $text');
                _responseController.add(text);
              }
              
              // Audio response
              if (part['inlineData'] != null) {
                final inlineData = part['inlineData'];
                if (inlineData['mimeType'] == 'audio/pcm') {
                  final audioData = base64Decode(inlineData['data']);
                  _logger.d('🔊 Audio received: ${audioData.length} bytes');
                  _audioResponseController.add(audioData);
                  _playAudio(audioData);
                }
              }
            }
          }
        }
        
        // Handle turn completion
        if (serverContent['turnComplete'] == true) {
          _logger.i('✅ Turn complete');
          _statusController.add('Ready');
        }
      }
    } catch (e) {
      _logger.e('Error processing response: $e');
    }
  }

  /// Send text message to Gemini
  Future<void> sendText(String text) async {
    if (!_isConnected) {
      _logger.w('⚠️ Not connected');
      return;
    }
    
    try {
      _logger.i('📤 Sending text: $text');
      
      final message = {
        'clientContent': {
          'turns': [
            {
              'role': 'user',
              'parts': [
                {
                  'text': text,
                },
              ],
            },
          ],
          'turnComplete': true,
        },
      };
      
      _wsChannel!.sink.add(jsonEncode(message));
      _statusController.add('Message sent');
    } catch (e) {
      _logger.e('Error sending text: $e');
    }
  }

  /// Start audio capture and streaming
  Future<void> startAudioStream() async {
    try {
      if (!await _audioRecorder.hasPermission()) {
        _logger.w('⚠️ Audio permission denied');
        return;
      }
      
      _logger.i('🎤 Starting audio capture');
      
      await _audioRecorder.start(
        path: '', // In-memory recording
        encoder: AudioEncoder.pcm16bits,
        sampleRate: 16000,
        numChannels: 1,
        bitRate: 128000,
      );
      
      // Stream audio to Gemini in chunks
      _audioSubscription = _audioRecorder.onFrameDecoded.listen((frame) {
        _sendAudioChunk(frame.data);
      });
      
      _statusController.add('Recording...');
    } catch (e) {
      _logger.e('Error starting audio: $e');
    }
  }

  /// Send audio chunk to Gemini
  void _sendAudioChunk(Uint8List audioData) {
    if (!_isConnected) return;
    
    try {
      final message = {
        'clientContent': {
          'turns': [
            {
              'role': 'user',
              'parts': [
                {
                  'inlineData': {
                    'mimeType': 'audio/pcm',
                    'data': base64Encode(audioData).toString(),
                  },
                },
              ],
            },
          ],
        },
      };
      
      _wsChannel!.sink.add(jsonEncode(message));
    } catch (e) {
      _logger.e('Error sending audio: $e');
    }
  }

  /// Stop audio capture
  Future<void> stopAudioStream() async {
    try {
      _logger.i('🛑 Stopping audio capture');
      await _audioRecription?.cancel();
      await _audioRecorder.stop();
      _statusController.add('Recording stopped');
    } catch (e) {
      _logger.e('Error stopping audio: $e');
    }
  }

  /// Capture and send camera frames
  Future<void> startCameraStream({int frameIntervalMs = 500}) async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      _logger.w('⚠️ Camera not initialized');
      return;
    }
    
    try {
      _logger.i('📷 Starting camera stream');
      
      _frameTimer = Timer.periodic(Duration(milliseconds: frameIntervalMs), (_) async {
        try {
          final image = await _cameraController!.takePicture();
          final bytes = await image.readAsBytes();
          
          // Compress image for efficiency
          final compressed = _compressImage(bytes);
          _sendCameraFrame(compressed);
        } catch (e) {
          _logger.d('Frame capture error: $e');
        }
      });
      
      _statusController.add('Camera streaming...');
    } catch (e) {
      _logger.e('Error starting camera: $e');
    }
  }

  /// Compress image for transmission
  Uint8List _compressImage(Uint8List imageBytes) {
    try {
      img.Image? image = img.decodeImage(imageBytes);
      if (image == null) return imageBytes;
      
      // Resize to max 1024x1024
      final resized = img.copyResize(
        image,
        width: image.width > 1024 ? 1024 : image.width,
        height: image.height > 1024 ? 1024 : image.height,
      );
      
      return Uint8List.fromList(img.encodeJpg(resized, quality: 85));
    } catch (e) {
      _logger.d('Compression failed, using original: $e');
      return imageBytes;
    }
  }

  /// Send camera frame to Gemini
  void _sendCameraFrame(Uint8List imageData) {
    if (!_isConnected) return;
    
    try {
      final message = {
        'clientContent': {
          'turns': [
            {
              'role': 'user',
              'parts': [
                {
                  'inlineData': {
                    'mimeType': 'image/jpeg',
                    'data': base64Encode(imageData).toString(),
                  },
                },
              ],
            },
          ],
        },
      };
      
      _wsChannel!.sink.add(jsonEncode(message));
    } catch (e) {
      _logger.e('Error sending frame: $e');
    }
  }

  /// Stop camera stream
  Future<void> stopCameraStream() async {
    try {
      _frameTimer?.cancel();
      _logger.i('🛑 Camera stream stopped');
    } catch (e) {
      _logger.e('Error stopping camera: $e');
    }
  }

  /// Play received audio
  Future<void> _playAudio(Uint8List audioData) async {
    try {
      await _audioPlayer.play(BytesSource(audioData));
    } catch (e) {
      _logger.e('Error playing audio: $e');
    }
  }

  /// Disconnect from Gemini
  Future<void> disconnect() async {
    try {
      _logger.w('🔌 Disconnecting...');
      
      await stopAudioStream();
      await stopCameraStream();
      await _audioPlayer.stop();
      
      _wsChannel?.sink.close(status.goingAway);
      _isConnected = false;
      
      _logger.i('✅ Disconnected');
      _statusController.add('Disconnected');
    } catch (e) {
      _logger.e('Error disconnecting: $e');
    }
  }

  /// Dispose resources
  Future<void> dispose() async {
    try {
      await disconnect();
      await _cameraController?.dispose();
      await _audioRecorder.dispose();
      await _audioPlayer.dispose();
      
      await _responseController.close();
      await _audioResponseController.close();
      await _statusController.close();
      
      _logger.i('🗑️ Disposed');
    } catch (e) {
      _logger.e('Error disposing: $e');
    }
  }
}
