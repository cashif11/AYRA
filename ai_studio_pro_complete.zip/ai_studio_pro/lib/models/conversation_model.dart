class ConversationMessage {
  final String id;
  final String sessionId;
  final String text;
  final String sender; // 'user' or 'ai'
  final DateTime timestamp;
  final String type; // 'text', 'audio', 'image'
  final String? audioPath;
  final String? imagePath;
  final Map<String, dynamic>? metadata;

  ConversationMessage({
    required this.id,
    required this.sessionId,
    required this.text,
    required this.sender,
    required this.timestamp,
    required this.type,
    this.audioPath,
    this.imagePath,
    this.metadata,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'sessionId': sessionId,
      'text': text,
      'sender': sender,
      'timestamp': timestamp.toIso8601String(),
      'type': type,
      'audioPath': audioPath,
      'imagePath': imagePath,
      'metadata': metadata,
    };
  }

  factory ConversationMessage.fromJson(Map<String, dynamic> json) {
    return ConversationMessage(
      id: json['id'],
      sessionId: json['sessionId'],
      text: json['text'],
      sender: json['sender'],
      timestamp: DateTime.parse(json['timestamp']),
      type: json['type'],
      audioPath: json['audioPath'],
      imagePath: json['imagePath'],
      metadata: json['metadata'],
    );
  }
}

class ConversationSession {
  final String id;
  final DateTime createdAt;
  final String title;
  final String mode; // 'audio', 'camera', 'combined', 'text'
  int messageCount;
  DateTime? lastUpdated;

  ConversationSession({
    required this.id,
    required this.createdAt,
    required this.title,
    required this.mode,
    this.messageCount = 0,
    this.lastUpdated,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt.toIso8601String(),
      'title': title,
      'mode': mode,
      'messageCount': messageCount,
      'lastUpdated': lastUpdated?.toIso8601String(),
    };
  }

  factory ConversationSession.fromJson(Map<String, dynamic> json) {
    return ConversationSession(
      id: json['id'],
      createdAt: DateTime.parse(json['createdAt']),
      title: json['title'],
      mode: json['mode'],
      messageCount: json['messageCount'] ?? 0,
      lastUpdated: json['lastUpdated'] != null 
          ? DateTime.parse(json['lastUpdated'])
          : null,
    );
  }
}

class AIConfig {
  final String apiKey;
  final String model;
  final String voice;
  final bool audioEnabled;
  final bool cameraEnabled;
  final int audioSampleRate;
  final int frameRate;
  final String systemPrompt;

  AIConfig({
    required this.apiKey,
    this.model = 'models/gemini-2.5-flash-native-audio-preview-12-2025',
    this.voice = 'Zephyr',
    this.audioEnabled = true,
    this.cameraEnabled = true,
    this.audioSampleRate = 16000,
    this.frameRate = 2, // 2 FPS
    this.systemPrompt = 'You are a professional AI assistant.',
  });

  Map<String, dynamic> toJson() {
    return {
      'apiKey': apiKey,
      'model': model,
      'voice': voice,
      'audioEnabled': audioEnabled,
      'cameraEnabled': cameraEnabled,
      'audioSampleRate': audioSampleRate,
      'frameRate': frameRate,
      'systemPrompt': systemPrompt,
    };
  }
}

class ApiResponse {
  final bool success;
  final String? message;
  final dynamic data;
  final String? error;

  ApiResponse({
    required this.success,
    this.message,
    this.data,
    this.error,
  });
}
