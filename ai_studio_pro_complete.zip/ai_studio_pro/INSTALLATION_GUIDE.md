# AI Studio Pro - Complete Installation Guide

## 🚀 Quick Start (5 minutes)

### Prerequisites
- Android Studio or Flutter CLI
- Flutter SDK 3.0+
- Android device or emulator (API 21+)
- Google Gemini API key (free)

### Step 1: Get Flutter
```bash
# Download Flutter from https://flutter.dev/docs/get-started/install
# Or if you have it:
flutter --version
```

### Step 2: Clone/Extract Project
```bash
cd ai_studio_pro
```

### Step 3: Install Dependencies
```bash
flutter pub get
```

### Step 4: Get Your API Key
1. Go to https://ai.google.dev
2. Click "Get API Key"
3. Create new API key for Gemini
4. Copy the key

### Step 5: Run the App
```bash
# On physical device
flutter run

# On emulator
flutter run -d emulator-5554

# With specific device
flutter devices
flutter run -d <device_id>
```

## 🔧 Full Setup Instructions

### 1. Flutter Installation

#### macOS/Linux
```bash
# Download and extract
tar xf flutter_linux_v3.16.0-stable.tar.xz
# Add to PATH
export PATH="$PATH:$HOME/flutter/bin"

# Verify
flutter doctor
```

#### Windows
```powershell
# Download flutter_windows_3.16.0-stable.zip
# Extract to C:\
# Add C:\flutter\bin to PATH environment variable

# Verify
flutter doctor
```

### 2. Android SDK Setup
```bash
# Accept Android licenses
flutter doctor --android-licenses

# Check setup
flutter doctor
```

### 3. Project Setup

```bash
# Get dependencies
flutter pub get

# Upgrade packages
flutter pub upgrade

# Clean (if having issues)
flutter clean
flutter pub get
```

### 4. API Key Configuration

#### Option A: Via App Setup Screen (Recommended)
1. Launch app
2. Enter API key in setup screen
3. Tap "Continue"

#### Option B: Via Code
Edit `lib/main.dart`:
```dart
await _aiProvider.initialize(apiKey: 'your_api_key_here');
```

#### Option C: Via Environment Variable
```bash
flutter run --dart-define=GEMINI_API_KEY=your_key_here
```

#### Option D: Via Local Configuration
Create `lib/config/api_config.dart`:
```dart
const String GEMINI_API_KEY = 'your_api_key_here';
```

Update `lib/services/gemini_live_service.dart`:
```dart
import 'package:ai_studio_pro/config/api_config.dart';

// In initialize():
_apiKey = GEMINI_API_KEY;
```

## 🏃 Running the App

### Development Mode
```bash
flutter run
```

### Release Mode (Optimized)
```bash
flutter run --release
```

### Hot Reload (During Development)
```bash
# After making code changes, in flutter console:
r  # Hot reload
R  # Hot restart
q  # Quit
```

## 📦 Building APK

### Debug APK (for testing)
```bash
flutter build apk --debug
# Location: build/app/outputs/flutter-apk/app-debug.apk
```

### Release APK (for distribution)
```bash
# Without signing (debug signature)
flutter build apk --release

# With proper signing
flutter build apk --release \
  --build-name=1.0.0 \
  --build-number=1
```

### App Bundle (for Play Store)
```bash
flutter build appbundle --release

# Location: build/app/outputs/bundle/release/app-release.aab
```

## 🔐 Signing the APK

### Generate Keystore
```bash
keytool -genkey -v -keystore ~/ai-studio-key.jks \
  -keyalg RSA -keysize 2048 \
  -validity 10000 \
  -alias ai_studio
```

### Create Signing Config
Create `android/key.properties`:
```properties
storeFile=/path/to/ai-studio-key.jks
storePassword=your_password
keyPassword=your_password
keyAlias=ai_studio
```

### Build Signed APK
```bash
flutter build apk --release
```

## 🧪 Testing

### Run Tests
```bash
flutter test
```

### Run on Specific Device
```bash
# List devices
flutter devices

# Run on device
flutter run -d <device_id>
```

### Test Specific Features
```bash
# Test API connection
flutter run --dart-define=TEST_API=true

# Test camera
flutter run --dart-define=TEST_CAMERA=true
```

## 🐛 Troubleshooting

### Issue: "Flutter SDK not found"
**Solution:**
```bash
# Add Flutter to PATH
export PATH="$PATH:$HOME/flutter/bin"

# Verify
flutter --version
```

### Issue: "Android SDK not found"
**Solution:**
```bash
# Accept licenses
flutter doctor --android-licenses

# Install SDK
# Use Android Studio: Tools > SDK Manager
```

### Issue: "Gradle build failed"
**Solution:**
```bash
# Clean and rebuild
flutter clean
flutter pub get
flutter pub upgrade
flutter run
```

### Issue: "API key invalid"
**Solution:**
1. Verify key from https://ai.google.dev
2. Check Gemini API is enabled in Google Cloud Console
3. Check API hasn't expired
4. Try new key

### Issue: "Camera not working"
**Solution:**
```bash
# Grant permissions in app settings
# Settings > Apps > AI Studio Pro > Permissions

# Or reset permissions
adb shell pm grant com.aistudio.pro android.permission.CAMERA
adb shell pm grant com.aistudio.pro android.permission.RECORD_AUDIO
```

### Issue: "Microphone issues"
**Solution:**
1. Grant RECORD_AUDIO permission
2. Check device isn't in silent mode
3. Test microphone with system app first
4. Restart app

### Issue: "App crashes on startup"
**Solution:**
```bash
# Run with verbose logging
flutter run -v

# Check logs
flutter logs

# Clean rebuild
flutter clean
flutter pub get
flutter run
```

### Issue: "Memory/Storage issues"
**Solution:**
```bash
# Clear app data
adb shell pm clear com.aistudio.pro

# Clear Flutter cache
flutter clean

# Rebuild
flutter pub get
flutter run
```

## 📊 Performance Optimization

### Debug Profiling
```bash
# Enable performance monitoring
flutter run --profile

# Generate timeline
flutter run --trace-startup
```

### Reduce Build Size
```bash
# Use release mode
flutter run --release

# Enable shrinking
# Already in build.gradle: minifyEnabled = true

# Reduce APK size
# Built-in optimization in release build
```

### Memory Monitoring
```bash
# In app console during run:
# DevTools will show memory usage at
# http://localhost:9100
```

## 🌐 Network Configuration

### For VPN/Proxy
Edit `android/app/build.gradle`:
```gradle
android {
    defaultConfig {
        // Enable cleartextTraffic if needed (not recommended for production)
        // android:usesCleartextTraffic="true"
    }
}
```

### Check Connection
```bash
# Test API connectivity
adb shell am start -a android.intent.action.VIEW -d "https://ai.google.dev"
```

## 📱 Device-Specific Setup

### Emulator Setup
```bash
# Create emulator
avdmanager create avd -n ai_studio -k "system-images;android-33;google_apis;x86_64"

# Launch
emulator -avd ai_studio

# In Flutter
flutter run -d emulator-5554
```

### Physical Device Setup
1. Enable USB Debugging
   - Settings > About > Build number (tap 7 times)
   - Back to Settings > Developer Options > USB Debugging

2. Connect USB cable

3. Verify connection
   ```bash
   adb devices
   ```

4. Run app
   ```bash
   flutter run
   ```

## 🔒 Security Checklist

- [ ] API key stored securely (not in code)
- [ ] HTTPS enforced for API calls
- [ ] Permissions minimized
- [ ] User data encrypted
- [ ] Sensitive logs removed
- [ ] Code obfuscated in release build
- [ ] Dependencies updated

## 📈 Deployment

### Internal Testing
```bash
# Build and share APK
flutter build apk --release

# Share build/app/outputs/flutter-apk/app-release.apk
```

### Google Play Store
1. Create Play Store account ($25)
2. Create application
3. Sign APK
4. Upload app bundle
5. Fill store listing
6. Submit for review

### Beta Testing
1. Google Play Console > Testing > Internal testing
2. Upload APK
3. Share link with testers
4. Collect feedback

## 📞 Support Resources

- Flutter Docs: https://flutter.dev/docs
- Dart Language: https://dart.dev
- Android Dev: https://developer.android.com
- Google AI API: https://ai.google.dev
- Flutter Pub: https://pub.dev

## ✅ Verification Checklist

After installation:
- [ ] App starts without crashes
- [ ] Setup screen appears
- [ ] API key input works
- [ ] Connect button functions
- [ ] Microphone is accessible
- [ ] Camera works (if available)
- [ ] Messages send successfully
- [ ] Responses appear in chat
- [ ] App doesn't crash on disconnect
- [ ] Storage/database works

---

**Ready to go!** 🎉 Your AI Studio Pro is ready to use.
